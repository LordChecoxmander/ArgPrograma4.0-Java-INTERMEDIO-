package Ejercicio1;

import java.util.List;

@FunctionalInterface
public interface Mayuscula {
	
	List<String> change (List<String> lis_origin);
}
