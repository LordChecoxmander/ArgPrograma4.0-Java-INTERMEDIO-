package Ejercicio1;

import java.util.List;

@FunctionalInterface
public interface MayusculaNumero {
	
	public String changeN (List<String> lisOrigin, int num);
}
